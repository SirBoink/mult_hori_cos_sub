"""Functions to BIDSify and deBIDSify data."""
import os
import glob
import re
import json

import ipdb
import pandas as pd
import numpy as np
from scipy.interpolate import interp1d

import utils

SPEED_THRESHOLD = 50  # mm/s
MAINTAIN = 10  # frames
DT = 0.01  # framerate from QTM.

DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FOLDER = os.path.abspath('../sourcedata/')
DATA_FILE = '../sourcedata/all_data.csv'

BIDS_FOLDER = '../'


def load_data():
    """Load the csv file with all the data.

    The only advantage of this is speed. This csv file has to have been created
    manually and might not be up-to-date. Use import_data() instead if you want
    to import from scratch.
    """
    return pd.read_csv(DATA_FILE, index_col=0)


def bidify_all(participants=None):
    """Load and save all data, raw and resampled."""
    # data_raw = import_data(participants=participants, raw=True)
    # data_raw.rename(columns={'pos_x': 'SensorID_0_x',
    #                          'pos_y': 'SensorID_0_y', 'tframe': 'time'},
    #                 inplace=True)
    # save_bids(data_raw, raw=True)

    data_re = import_data(participants=participants, raw=False)
    data_re.rename(columns={'pos_x': 'SensorID_0_x',
                            'pos_y': 'SensorID_0_y', 'tframe': 'time'},
                   inplace=True)
    save_bids(data_re, raw=False)


def save_bids(data, raw, bids_dir=BIDS_FOLDER):
    """Save data in BIDS format.

    Parameters
    ----------
    data : pd.DataFrame
    Data, all lumped together, in the format of import_data.

    raw : Bool
    If True, the filename has _raw suffixed.
    """
    data.loc[:, 'reference_frame'] = 'global'
    meta_cols = ['part', 'condition', 'id_move']
    # save_cols = ['pos_x', 'pos_y', 'tframe', 'frame', 'ctarget',
    #              'condition', 'first', 'second', 'third', 'fourth'] + meta_cols
    file_stem = './sub-{}_task-{}_tracksys-qualisys'
    subfolder = bids_dir + './sub-{}/motion/'
    for meta, datum in data.groupby(meta_cols):
        part, cond, idmove = meta
        c_subfolder = subfolder.format(int(part))
        if not os.path.exists(c_subfolder):
            os.makedirs(c_subfolder)
        filename = c_subfolder + file_stem + '_motion' + '_raw' * raw + '.tsv'
        task = cond + str(idmove)
        c_filename = filename.format(part, task)
        datum.to_csv(c_filename, sep='\t', index=False)
        event_stem = c_subfolder + file_stem.format(part, task)
        qualisys_json(c_filename, task)
        save_events(datum, event_stem)


def save_events(data, file_stem):
    """Extract the times in which targets are reached and save separately."""
    circles = utils.coords_from_svg('mk_tr')
    in_start = circles['pt_start'](
        data[['SensorID_0_x', 'SensorID_0_y']].values)
    ix_first_out = np.where(in_start == 0)[0][0]
    ix_last_out = np.where(in_start == 0)[0].max()
    ordinals = ['second', 'third']
    target_times = data.groupby(['ctarget'])['time'].max()
    targets = data[ordinals].values[0]
    first_time = data['time'].min()
    events = []
    times = []
    rel_times = []
    events.append('exited_start')
    times.append(data.iloc[ix_first_out]['time'])
    rel_times.append(times[-1] - first_time)
    for label, target in zip(ordinals, targets):
        if pd.isnull(target):
            continue
        events.append(f'reached_{label}_target')
        times.append(target_times[target])
        rel_times.append(target_times[target] - first_time)

    events.append('entered_final')
    times.append(data.iloc[ix_last_out]['time'])
    rel_times.append(times[-1] - first_time)
    filename = file_stem + '_events.tsv'
    durations = [0] * len(rel_times)
    panda = pd.DataFrame(data=np.array([times, durations, events]).T,
                         columns=['onset', 'duration', 'trial_type'])
    panda.to_csv(filename, index=False, sep='\t')


def qualisys_json(filename, taskname):
    """Write a json on qualisys."""
    dicty = {'SamplingFrequency': 100,
             'TrackingSystemName': 'Qualisys',
             'TaskName': taskname}
    filename_json = filename[:-4] + '.json'
    with open(filename_json, 'w') as mafi:
        mafi.write(json.dumps(dicty))


def import_data(participants=None, data_folder=None,
                raw=False):
    """Import the requested data files into a big happy panda.

    Only successful trials are included.

    Parameters
    ----------
    participants : iterable[int]
    Participant numbers to take.

    conditions : list[str]
    List containing 'single' and/or 'sequential'. If None, both are imported.

    raw : Bool
    If False, data is re-sampled (after fixing the tframe snafu. See READ.me).

    Returns
    -------
    pandata : pd.DataFrame
    Contains the data for all requested participants and conditions. Each row
    is one measurement and the columns are all those in the data.

    """
    if data_folder is None:
        data_folder = DATA_FOLDER
    if participants is None:
        participants = find_participants(data_folder=data_folder)
        if len(participants) == 0:
            messy = f'No participant data found in {data_folder}'
            raise ValueError(messy)
    pandota = []
    for part in participants:
        filename = data_folder + '/data_{}.csv'
        pandita = pd.read_csv(filename.format(part))
        pandita['part'] = part
        fix_condition(pandita)
        pandota.append(pandita.query('success'))
    pandota = pd.concat(pandota, ignore_index=True)
    pandota['unique_trial_id'] = unique_run_identifier(pandota)
    if not raw:
        fix_frames(pandota)
        pandota = resample_sensor_data(pandota)
    else:
        pandota['tframe'] = pandota['frame'] * 0.01
    label_current_target(pandota)
    return pandota


def resample_sensor_data(data, target_freq=100):
    """Resample sensor data to a target frequency using polynomial interpolation.

    Takes a DataFrame with trajectory data and resamples it to the target
    frequency (default 100 Hz) for each unique trial separately. Uses polynomial
    interpolation to maintain smoothness of trajectories.

    Parameters
    ----------
    data : pd.DataFrame
        Input DataFrame containing sensor data. Must include columns:
        - 'unique_trial_id': unique identifier for each trial
        - 'tframe': timestamp column (in milliseconds)
        - 'pos_x': x position coordinate
        - 'pos_y': y position coordinate
        - 'frame': frame number (will be recomputed)
        Other columns will be preserved with their first value per trial.
    target_freq : float, optional
        Target sampling frequency in Hz (default: 100)

    Returns
    -------
    pd.DataFrame
        Resampled DataFrame with:
        - 'pos_x', 'pos_y', 'tframe' resampled at target_freq
        - 'frame' renumbered as 0, 1, 2, ...
        - All other columns preserved with values from the trial

    Notes
    -----
    - Uses cubic polynomial interpolation (kind='cubic') for smoothness
    - Resampling period = 1000 ms / target_freq
    - Each unique_trial_id is processed independently
    - Non-resampled columns take their first value within each trial
    - NaN values in pos_x/pos_y are treated as missing data and interpolated over
    - Trials with fewer than 2 valid data points are skipped

    Created by Claude (claude-sonnet-4-5) on 2025-11-27
    Modified by Claude (claude-sonnet-4-5) on 2025-12-01
    """
    resampled_trials = []

    for _, datum in data.groupby('unique_trial_id'):
        trial_data = datum.copy()

        # Get time range for this trial
        t_min = trial_data['tframe'].min()
        t_max = trial_data['tframe'].max()

        # Calculate sampling period in milliseconds
        dt = 1 / target_freq

        # Create new time array at target frequency
        t_new = np.arange(t_min, t_max + dt/2, dt)

        # Sort by time for interpolation
        trial_data = trial_data.sort_values('tframe')
        t_old = trial_data['tframe'].values

        # Handle NaNs by filtering them out before interpolation
        pos_x_vals = trial_data['pos_x'].values
        pos_y_vals = trial_data['pos_y'].values

        # Find indices where both coordinates are valid (not NaN)
        valid_mask = ~(np.isnan(pos_x_vals) | np.isnan(pos_y_vals))

        if valid_mask.sum() < 2:
            # Not enough valid points for interpolation, skip this trial
            continue

        t_valid = t_old[valid_mask]
        pos_x_valid = pos_x_vals[valid_mask]
        pos_y_valid = pos_y_vals[valid_mask]

        # Interpolate pos_x and pos_y using cubic polynomial on valid data
        interp_x = interp1d(t_valid, pos_x_valid,
                            kind='cubic', bounds_error=False,
                            fill_value='extrapolate')
        interp_y = interp1d(t_valid, pos_y_valid,
                            kind='cubic', bounds_error=False,
                            fill_value='extrapolate')

        pos_x_new = interp_x(t_new)
        pos_y_new = interp_y(t_new)

        # Create new dataframe for resampled trial
        resampled_trial = pd.DataFrame({
            'tframe': t_new,
            'pos_x': pos_x_new,
            'pos_y': pos_y_new,
            'frame': np.arange(len(t_new))
        })

        # Add non-resampled columns (use first value from trial)
        for col in trial_data.columns:
            if col not in ['tframe', 'pos_x', 'pos_y', 'frame']:
                resampled_trial[col] = trial_data[col].iloc[0]
        resampled_trials.append(resampled_trial)

    # Concatenate all resampled trials
    result = pd.concat(resampled_trials, ignore_index=True)

    return result


def unique_run_identifier(data, append=True):
    """Return a numerical identifier for each trial.

    This number is uniquely determined by the participant number, condition,
    id_move and trial number using the following logic:

    All numbers start with a 1, to avoid python freaking out about leading
    zeroes in an int. From there: The first four digits are the participant
    numbers (with added leading zeroes, if needed). The fifth digit is
    condition (0 for single-target, 1 for sequential). The sixth and seventh
    are id_move (with leading zero, if needed) and the last three digits are
    trial number (with leading zeroes, if needed).

    """
    part = data['part']
    cond = data['condition'] == 'sequential'
    idmove = data['id_move']
    trial = data['trial']

    def formy(x, n):
        temp = f'{{:0{n}d}}'
        return temp.format(x)
    that = []
    for this, n in zip([part, cond, idmove, trial], [4, 1, 2, 3]):
        that.append(this.map(lambda x: formy(x, n)).values)
    final = '1' + np.sum(that, axis=0)
    finalint = final.astype(int)
    if append:
        data['unique_trial_id'] = finalint
    return finalint


def find_participants(data_folder=None):
    """Return a list of participants for which the experimental data exists."""
    if data_folder is None:
        data_folder = DATA_FOLDER
    files = glob.glob(data_folder + '/*.csv')
    participants = []
    for c_file in files:
        try:
            participants.append(int(re.search(r'[0-9]+', c_file)[0]))
        except TypeError:
            pass

    return sorted(participants)


def label_current_target(data, method_center=None, speed_threshold=0.1,
                         last_segment_peak_threshold=None):
    """Infer and label the current target in the trajectory.

    Copied over from proj_hands.

    Given  each  trial (unique_trial_id),  use  some  heuristics to  label  the
    current target circle for each frame in the data.

    Iterates through each unique trial (`unique_trial_id`) in the provided
    DataFrame. For each trial, it uses heuristics to determine which target
    circle the trajectory is currently associated with at each time frame.
    The inferred target label is added to the DataFrame in a new column named
    'ctarget'.

    The heuristic involves finding when the trajectory enters and exits the
    area defined by each target circle in the sequence. The exact frame where
    the transition between targets is considered to occur (`cutoff`) is
    determined by the `method_center` parameter:
        - 'time': Midpoint in time between entering and exiting the circle.
        - 'pspeed': Frame with the minimum speed of the 'pos_x', 'pos_y'
                    coordinates while inside the circle.
        - 'hspeed': Frame with the minimum speed of the hand markers
                    (from `get_sensor_labels(only_hand=True)`) while inside
                    the circle.

    This function modifies the input DataFrame in-place.

    Special handling for final targets:
    - When target is 'pt_start' (return to start), uses peak-speed + settling 
      logic to remove final frames not relevant for analysis
    - For other final targets (e.g., 'gestrain' condition), uses minimum speed
      to find the natural settling point without removing useful data

    Modified by Claude Sonnet 4 on 2025-07-31.
    Further modified by Claude Sonnet 4 on 2025-08-26 to add peak threshold option for last segment.

    Parameters
    ----------
    data : pd.DataFrame
        Input data containing trajectory information (including 'pos_x',
        'pos_y', 'unique_trial_id', and target sequence columns like
        'second', 'third', etc.). Sensor data might be needed depending
        on `method_center`.
    method_center : str, optional
        The method used to determine the center point (cutoff) of the time
        spent within a target circle. Valid options are 'time', 'pspeed',
        or 'hspeed'. If None, defaults to the value of the global variable
        `METHOD_CENTER`.
    last_segment_peak_threshold : float, optional
        If provided, the last segment of each trajectory will use this threshold
        (as a proportion of peak speed) instead of minimum speed detection.
        E.g., 0.2 means target reached when speed drops to 20% of peak speed
        in that segment. Only applies when method_center is 'pspeed' or 'hspeed'.

    Returns
    -------
    None
        The function modifies the `data` DataFrame in-place by adding the
        'ctarget' column.

    Raises
    ------
    ValueError
        If the provided `method_center` is not one of the valid options.

    """
    if method_center is None:
        method_center = 'pspeed'
    if method_center in ['time', 'pspeed']:
        sensors = ['pos_x', 'pos_y']
    elif method_center == 'hspeed':
        sensors = get_sensor_labels(data, only_hand=True)
    else:
        raise ValueError(f'Wtf? --method_center-- was {method_center}, '
                         'which is weird.')

    basket = utils.coords_from_svg(reference='mk_tr')
    for _, datum in data.groupby('unique_trial_id'):
        c_target = np.empty(len(datum), dtype=object)
        targets = datum.iloc[0][['second', 'third', 'fourth']].values
        # Find the last non-null target for peak threshold logic
        valid_targets = [t for t in targets if not pd.isnull(t)]
        last_target = valid_targets[-1] if valid_targets else None
        p_cutoff = 0
        if method_center in ['pspeed', 'hspeed']:
            forspeed = datum.loc[:, sensors]
            forspeed.interpolate(method='linear', axis=1, inplace=True)
            speed = np.linalg.norm(np.gradient(
                forspeed.values, axis=0), axis=1)
        for target in targets:
            if pd.isnull(target):
                break
            # last_target = target  # For later
            circle = basket[target]
            traj = datum.loc[:, ['pos_x', 'pos_y']].values
            ixs_found = circle(traj)
            found = np.where(ixs_found)[0]
            try:
                found_first = found[found > p_cutoff][0]
            except IndexError:
                # Target never reached.
                c_target[p_cutoff:] = target
                break
            # found_first = found[found > p_cutoff][0]
            exit_all = np.where(ixs_found == 0)[0]
            if exit_all.max() < found_first:
                # Participant never exits the target circle after entering
                if method_center == 'time':
                    cutoff = len(datum)
                elif method_center in ['hspeed', 'pspeed']:
                    # Only apply "remove settling frames" logic if returning to start
                    if target == 'pt_start':
                        # Find peak speed and then when it settles below threshold
                        zpeed = speed[p_cutoff:]
                        ix_speed_max = zpeed.argmax()
                        speed_max = speed[ix_speed_max]
                        try:
                            cutoff = p_cutoff + ix_speed_max + np.where(
                                zpeed[ix_speed_max:] <= speed_threshold * speed_max)[0][0]
                        except IndexError:
                            cutoff = len(datum)
                    else:
                        # For non-pt_start targets (e.g., gestrain), use minimum speed or end
                        # Check if this is the last segment and peak threshold is enabled
                        if (last_segment_peak_threshold is not None and
                            target == last_target and
                                method_center in ['pspeed', 'hspeed']):
                            # Use peak speed threshold method for last segment
                            cutoff = _find_cutoff_peak_threshold(
                                speed, found_first, last_segment_peak_threshold)
                        else:
                            try:
                                # Find minimum speed point from entry onward
                                cutoff = np.argmin(
                                    speed[found_first:]) + found_first
                            except (IndexError, ValueError):
                                cutoff = len(datum)
            else:
                exit_first = exit_all[exit_all > found_first][0]
                if method_center == 'time':
                    cutoff = int((found_first + exit_first) / 2)
                elif method_center in ['hspeed', 'pspeed']:
                    # Check if this is the last segment and peak threshold is enabled
                    if (last_segment_peak_threshold is not None and
                            target == last_target):
                        # Use peak speed threshold method for last segment, but constrain to exit
                        peak_cutoff = _find_cutoff_peak_threshold(
                            speed, found_first, last_segment_peak_threshold)
                        cutoff = min(peak_cutoff, exit_first)
                    else:
                        cutoff = np.argmin(
                            speed[found_first:exit_first]) + found_first
            c_target[p_cutoff:cutoff] = target
            p_cutoff = cutoff
        c_target[cutoff:] = 'end'
        data.loc[datum.index, ['ctarget']] = c_target


def fix_frames(pandata, inplace=True, force_unique_id=False):
    """Fix the problem with not recording dt in the data.

    The data points recorded in psychopy are not always at even intervals due
    to programming error. This leads to the speed seemingly doubling from one
    row to the next in the pandas.

    To fix this, a new column dt is created with integers, where the value for
    each row is how many frames this measurement was held, with 1 being the
    default. For any row idx, id[idx] is a number (typically 1 or 2) such that
    the right-speed is calculated as (pos[idx + 1] - pos[idx]) / dt[idx].

    Additionally, for compatibility with proj_switch and proj_hands, a column
    tframe is created. This works as a timestamp in seconds, starting at 0 for
    each participant and running until the end of the recording for this
    participant. It respects the newly-calculated dt.

    This function assumes that the panda already has the 'unique_trial_id'
    column. If --force_unique_id-- is True, unique_run_identifier will be
    called to add it. Otherwise, an error is thrown.

    """
    if not inplace:
        pandata = pandata.copy()
    if 'unique_trial_id' not in pandata.columns:
        if force_unique_id:
            unique_run_identifier(pandata, append=True)
        else:
            raise ValueError('The panda provided is missing the '
                             '"unique_trial_id" column. Run the '
                             'unique_run_identifier function to add it.')
    pandata.loc[:, ['dt']] = 1.0
    for unique_id in pd.unique(pandata['unique_trial_id']):
        datum = pandata.query('unique_trial_id == @unique_id')
        c_dt = _fix_frames_one(datum)
        pandata.loc[datum.index, 'dt'] = c_dt
        pandata.loc[datum.index, 'frame'] += np.cumsum(c_dt - 1)

    # Add tframe
    pandata.loc[:, ['tframe']] = 0
    for part, datum in pandata.groupby('part'):
        tframe = np.roll(np.cumsum(datum['dt'].values) * DT, 1)
        tframe[0] = 0
        pandata.loc[datum.index, ['tframe']] = tframe
    if not inplace:
        return pandata


def _fix_frames_one(pandatum):
    """Calculate the new dt column for one run.

    Hack(1): The first two positions of each trial are exactly the same, for
    some weird reason. To avoid warnings about division by zero, I added a
    +1e-5 to speeds, which affects nothing (I hope). Need to fix this
    elsewhere.

    """
    diff = np.diff(pandatum.loc[:, ['pos_x', 'pos_y']], axis=0)
    c_dt = pandatum['dt'][:-1].values
    qspeed = np.linalg.norm(diff, axis=1) + 1e-5  # Hack(1)!
    if (qspeed == 0).any():
        ipdb.set_trace()
    ix_test = 0
    double = np.array([True])  # changes size later in loop
    while double.any():
        if ix_test > 10:
            break
        c_speed = qspeed / c_dt
        ratio = c_speed[1:] / c_speed[:-1]
        double = np.abs(ratio - 2) < 0.8
        c_dt[np.where(double)] = 0.5
        # ipdb.set_trace()
        ix_test += 1
    c_dt = np.concatenate([c_dt, [1]])
    return (c_dt * 2).astype(int)


def fix_condition(pandata, inplace=True):
    """Fix the problem with all conditions being sequential in 400 series.

    Somehow, the experiment records all trials as being sequential in the 400
    series of the experiment. This function fixes those labels, making all
    trials without a third target a single-target trial.

    Works in-place unless otherwise specified.

    """
    if not inplace:
        pandata = pandata.copy()

    single = pandata['third'].isnull()
    if not single.any():
        single = pandata['third'] == 'none'
    condition = np.where(single, 'single', 'sequential')
    pandata['condition'] = condition
    if not inplace:
        return pandata
