"""Examples for using the included code."""

import logging

import numpy as np

import bids
import utils
import import_data as imda

logging.basicConfig(level=logging.INFO)


def importing_source_data():
    """Directly importing/loading the source data.

    This is what was used in the related study.
    """
    try:
        # If the source_data/all_data.csv file exists, it can be loaded
        logging.info('Attempting to load pre-processed data from single file')
        data = imda.load_data()
        logging.info('Data loaded from single file.')
    except FileNotFoundError:
        # If not, data can be imported from individual files
        # Default parameters were used in the study.
        logging.info('all_data.py file not found. Loading from all files')
        data = imda.import_data()
        logging.info('Loaded and pre-processed data from all files')
        logging.info('Saving pre-processed data')
        imda.save_data(data)  # saved for future uses
        logging.info('Pre-processed data saved.')

    return data


def source_to_bids():
    """Transform the source data to the BIDS-formatted data.

    Writes both the raw and re-sampled data.

    """
    bids.bidify_all()


def using_utils():
    """Use the included utilities with the data."""
    data = importing_source_data()

    # Select one random trial
    uid = np.random.choice(np.unique(data['unique_trial_id']))
    datum = data.loc[data['unique_trial_id'] == uid]

    # Getting an instance of the printout
    basket = utils.coords_from_svg()

    # Extracting trajectory
    traj = datum[['pos_x', 'pos_y']].values

    # Checking in which frames the trajectory was in the pt_left target
    in_ptleft = basket['pt_left'](traj)
    print('Number of frames inside pt_left: ', sum(in_ptleft))
