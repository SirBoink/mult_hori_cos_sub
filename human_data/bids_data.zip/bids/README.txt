* README
This dataset, titled "Sequential reaching movements with coarticulation",  accompanies a study on the hierarchical control of sequential movements. It provides tracking of the fingertip of human participants as they perform reaching/pointing movements towards multiple targets on a table in front of them.



* Key features
- Fingertip kinematics: tracked with the Qualisys system of infrarred cameras, capturing the position of reflective markers with millimeter-precision.
- Online checking of visited targets: Custom code checked that targets were reached in the requested order, providing online feedback when they were not.
- Experimental design: 20 participants performed reaching movements towards targets printed on the table, following instructions on a computer screen in front of them. The targets were divided into two primary and three secondary, and sequences consisted on a loop starting in a position near the participant's chest, going through a primary, then a secondary target, then back to the starting position. All combinations of primary-secondary were performed, with 20 repetitions per sequence. 10 repetitions each of single-target movements were also performed towards each of the primary targets.
- Pre-processing: Data was rotated and translated from the arbitrary room-based Cartesian coordinate system of the Qualisys software, into a Cartesian coordinate system centered on a marker on the table, and with axes parallel to the edges of the table. A correction to the timestamps was performed after measurement, and data was re-sampled to 100Hz.



* Applications
The dataset was collected to analyze measures of coarticulation in sequential movements of human participants.



* Contact person
Dr. Dario Cuevas Rivera: dario.cuevas_rivera@tu-dresden.de; ORCID: 0000-0003-0516-5210



* Years
2023


* Description of the task
Participants (N=20) sat at a table with a printout on it which displayed large colored circles that were to be the targets of reaching movements.

Reflective markers were placed on the participant's right hand to track their index fingertip. These markers reflect infrared light which is emitted and received by cameras that use it to track the position of the markers in space.

The experiment consisted of two conditions: (1) a single-target condition, where participants made repeated reaching movements to primary targets 1 or 2. Movements ended in the primary target and participants had to move back to the initial position only after hearing the auditory cue for the trial's end. (2) A sequential condition, where participants move their hand to a primary target, then a secondary target and finally back to the starting position, making it a 3-target sequence. Each movement was repeated 20 times. The order and numbering of the sequences is as follows, with the numbering corresponding to the column "id_move" in the data.
For single-target trials:
0: 0-1
1: 0-2

For sequential trials:
0: 0-1-3-0
1: 0-1-5-0
2: 0-1-4-0
3: 0-2-3-0
4: 0-2-5-0
5: 0-2-4-0

As above, the targets are labeled: 0: Starting position (gray); 1: blue (pt_left); 2: red (pt_right); 3: olive (st_left); 4: lilac (st_top); 5: pink (st_right). The label in parenthesis corresponds to the labels in the experiment_sheet.svg file, as well as in the data.



* Description of the data


** Post-measurement correction
The Qualisys system streams the data at regular intervals with a frequency of 100Hz. However, data collection was additionally synchronized with the refresh rate of the monitor, which was 60Hz. This means that the rows are not evenly spaced in time. This became a problem because a bug in our code lead to the frame's timestamps to be sometimes erroneously.

To correct for this, we used heuristics based on the speed of movement to correct the timestamps. The basic idea behind the calculation is that speeds should increase and decrease gradually, therefore if from one row to the next the speed doubles, it indicates that one frame was skipped, so the timestamp for the next row was set to +20ms that of the current one, instead of just 10ms.

The raw data included includes this correction. In addition, the data was re-sampled to 100Hz, and is included here alongside the raw (corrected) data. The source data is included in a separate folder (./origin/) in the exact format in which it was written by our custom code.

The code for correction and re-sampling are included (see Included Code below).


** Description of the data columns
The following columns were recorded:

time+ : Time in seconds, with an arbitrary starting point.
frame+ : Frame index, all trials starting at zero.
success : Whether the trial was successful
first/second/third/fourth : Identity of the first, second, third and fourth targets, respectively, as labelled in the file (e.g. pt_right). Note that the first and fourth targets are always pt_start.
id_move : Sequence number, as listed above. Noted that values of 0 or 1 could be either single-target or sequential trials, which can be checked in the "condition" columns.
part : Participant number
unique_trial_id+ : A number that uniquely identifies every participant-condition-sequence-trial combination. Selecting all rows with the same unique_trial_id will yield the entire recording for one trial.
ctarget+ : Current target for every row. This divides a trajectory into segments, with each segment having one target. See the section "Calculating ctarget" below for details.
SensorID_0_x/y* : Position in the xy plane, in millimeters. The positions are in the frame of reference of the room, with the origin being at the mk_tr marker on the printout (top-right), the x-axis being left-right (e.g. the line connecting the two top markers), and the y-axis being backward-forward. All values are negative, as all targets lie to the bottom-left of the mk_tr marker.
reference_frame : Always set to 'global' to denote that the coordinate system does not change, and is tied to the room.

Columns marked with * were obtained directly from the Qualisys system through its python API. Those marked with + were added after the experiment to facilitate analysis.


** Calculating the current target ('ctarget' column)
For single-target movements (single condition), the 'ctarget' is set to the only target (pt_left or pt_right) for all rows.

For sequential trials, we divided a trial's trajectory into segments. The first segment starts when the trajectory exceeds a speed of 50 mm/s and maintains it for at least 10 rows; at this point, the 'ctarget' goes from 'pt_start' to the value of the 'second' column. The end of this first segment, and the beginning of the second segment, was defined as the point of minimum speed within the circle of the primary target (pt_left or pt_right, depending on trial). The second segment ends at the point of minimum speed within the secondary target (pt_left, pt_right or pt_top) and continues until the end of the trial.


** Quality of the data
The trajectories were validated during measurement in two ways:
(1) all targets were visited in the correct order, including the initial position (at the beginning and end of all sequential trajectories).
(2) All trajectories were done with the requested average speed (i.e. between 600mm/s and 900mm/s).

Additionally, we checked variability in the presence and amount of coarticulation using two measures:
(1) Halfway coarticulation: we found that as trajectories go towards the first target, they deviate from the straight line that connects the initial position with the target. These deviations were predictive of the next target in the sequence, indicating coarticulation.
(2) Transitional coarticulation: Most trajectories did not go through the center of the target circles in sequential trajectories. Instead, we observed trajectories with "rounded off" corners, i.e. where the trajectory starts to move towards the next target before the center of the current target has been reached.


** Notes
Data was anonymized. Participants are identified only by their participant number (401-420).

Participants gave written consent.

The experiment was approved by the Ethics Commission of the Dresden University of Technology (SR-EK-189042023).

The experiment was designed by Dario Cuevas Rivera and Stefan Kiebel. Experimental stimuli and related printout was created by Dario Cuevas Rivera. All data was collected by Aleksandra Szpilska.



* Included code and other files
The code files included are those necessary for going from the source data to the BIDS-formatted data. To do this, install the python dependencies listed in requirements.txt (e.g. using poetry or anaconda), and execute 'python bids.py' from within the ./code/ directory.

The file experiment_sheet.svg is the printout used for the experiment, to be printed in an DINN A2 paper. The sizes and distances in the SVG file match those of the experiment and the data, in millimeters. The file utils.py contains functions to import the measurements in the printout into a python class instance that is compatible with the dataset. See the documentation in utils.py to use this.



* Data user agreement
This dataset is shared under the CC BY 4.0 license, allowing reuse with attribution.



* How to cite this work
Cuevas Rivera, Dario; Szpilska, Aleksandra; Kiebel, Stefan. Sequential reaching movements with coarticulation [Dataset]. Figshare.
